import React, { useEffect, useState } from 'react';
import { styled } from '@mui/material/styles';
import { Box, Typography } from '@mui/material';
import MainCard from 'ui-component/cards/MainCard';
import { Line } from 'react-chartjs-2';
import {
    Chart as ChartJS,
    Title,
    Tooltip,
    Legend,
    LinearScale,
    LineElement,
    BarElement,
    PointElement,
    CategoryScale,
    BarController,
    LineController,
} from 'chart.js';
import ChartDataLabels from 'chartjs-plugin-datalabels';
import api from './../../../api.js';

ChartJS.register(
    Title,
    Tooltip,
    Legend,
    LinearScale,
    LineElement,
    BarElement,
    PointElement,
    CategoryScale,
    BarController,
    LineController,
    ChartDataLabels // Register the plugin
);

const CardWrapper = styled(MainCard)(() => ({
    backgroundColor: 'white',
    color: '#fff',
    overflow: 'hidden',
    position: 'relative',
    height: '420px',
    borderRadius: '4px',
}));

const TempHum = () => {
    const [data, setData] = useState({
        temp: [],
        hum: [],
        comfortLevel: []
    });
    const [labels, setLabels] = useState([]); // New state for labels

    const fetchHourlyData = async () => {
        try {
            const response = await api.get('/integration/temp-hourly-data');
            const hourlyData = response.data;

            const temp = [];
            const hum = [];
            const comfortLevel = [];
            const labels = []; // This will hold the labels for the hours where data is present

            for (let i = 1; i <= 24; i++) {
                const hourKey = `${i}${i === 1 ? 'st' : i === 2 ? 'nd' : 'th'} hour`;
                const values = hourlyData[hourKey];

                if (values && values.Temp !== undefined && values.Hum !== undefined) {
                    const temperature = values.Temp;
                    const humidity = values.Hum;

                    temp.push(temperature);
                    hum.push(humidity);

                    // Determine comfort level based on temperature and humidity
                    let comfort = 4; // Default "No Data" state

                    if (temperature >= 20 && temperature <= 24 && humidity >= 30 && humidity <= 50) {
                        comfort = 1; // Good
                    } else if (
                        (temperature >= 25 && temperature <= 29 && humidity >= 30 && humidity <= 50) ||
                        (temperature >= 20 && temperature <= 24 && humidity >= 51 && humidity <= 60)
                    ) {
                        comfort = 2; // Moderate
                    } else if (
                        temperature < 18 || temperature > 29 ||
                        humidity < 20 || humidity > 60
                    ) {
                        comfort = 3; // Unhealthy
                    }

                    comfortLevel.push(comfort);
                    labels.push(`${i}`); // Add label only when there's data
                }
            }

            // Set state only with available data
            setData({ temp, hum, comfortLevel });
            setLabels(labels); // Set the labels state
        } catch (error) {
            console.error('Error fetching hourly data:', error);
        }
    };

    useEffect(() => {
        fetchHourlyData();
    }, []);

    const hasData = data.temp.length > 0 && data.hum.length > 0; // Check if there is data

    const options = {
        responsive: true,
        scales: {
            x: {
                type: 'category',
                title: {
                    display: true,
                    text: 'Hours',
                },
                ticks: {
                    autoSkip: false,
                },
            },
            y: {
                title: {
                    display: true,
                    text: 'Value',
                },
                beginAtZero: true,
            },
            comfortY: {
                position: 'right',
                title: false, // Set title to false to remove the "Comfort Level" label
                beginAtZero: true,
                ticks: {
                    display: false, // Set display to false to hide tick marks and labels
                },
                grid: {
                    drawOnChartArea: false,
                },
                barPercentage: 1.0,
                categoryPercentage: 1.0,
            },
        },
        plugins: {
            legend: {
                display: true,
                position: 'bottom',
            },
            tooltip: {
                enabled: true,
                callbacks: {
                    label: (tooltipItem) => {
                        const datasetIndex = tooltipItem.datasetIndex;
                        const value = tooltipItem.raw;

                        if (datasetIndex === 2) { // Comfort Level dataset index
                            const labels = ['No Data', 'Good', 'Moderate', 'Unhealthy'];
                            return `Comfort Level: ${labels[value]}`;
                        } else {
                            return `${tooltipItem.dataset.label}: ${value !== null ? value : 'No data'}`;
                        }
                    },
                },
            },
            datalabels: {
                display: false,
            },
        },
    };

    const chartDataCombined = {
        labels: labels, // Use only labels with corresponding data
        datasets: [
            {
                type: 'line',
                label: 'Temperature (°C)',
                data: data.temp,
                borderColor: '#31572c', // Changed temperature line color to #31572c
                backgroundColor: 'rgba(49, 87, 44, 0.2)', // Optional: light background color
                fill: false,
                pointRadius: 3,
            },
            {
                type: 'line',
                label: 'Humidity (%)',
                data: data.hum,
                borderColor: '#70d6ff', // Changed humidity line color to #70d6ff
                backgroundColor: 'rgba(112, 214, 255, 0.2)', // Optional: light background color
                fill: false,
                pointRadius: 3,
            },
            {
                type: 'bar',
                label: 'Comfort Level',
                data: data.comfortLevel,
                backgroundColor: (context) => {
                    const index = context.dataIndex;
                    const level = data.comfortLevel[index];
                    switch (level) {
                        case 1: return 'rgba(75, 192, 75, 1)'; // Green for Good
                        case 2: return 'rgba(255, 159, 64, 1)'; // Orange for Moderate
                        case 3: return 'rgba(255, 99, 132, 1)'; // Red for Unhealthy
                        default: return 'rgba(201, 203, 207, 1)'; // Gray for No Data
                    }
                },
                yAxisID: 'comfortY',
            },
        ],
    };

    return (
        <CardWrapper border={false} content={false}>
            <Box sx={{ p: 2.25, textAlign: 'center', height: '100%', display: 'flex', flexDirection: 'column' }}>
                <Typography sx={{ color: 'black', fontSize: '20px', mb: 1, textAlign: 'start' }}>
                    Comfort Level (Temperature VS Humidity)
                </Typography>
                <Box sx={{ flex: 1 }}>
                    {hasData ? (
                        <Line options={options} data={chartDataCombined} />
                    ) : (
                        <Typography>No Data Available</Typography>
                    )}
                </Box>
            </Box>
        </CardWrapper>
    );
};

export default TempHum;
