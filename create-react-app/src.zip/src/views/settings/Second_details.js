import React from 'react';
// import MainCard from 'ui-component/cards/MainCard';
import { Box, Typography } from '@mui/material';
import ErrorOutlineIcon from '@mui/icons-material/ErrorOutline';
// import image from './../settings/kaitara1.png';
import './../utilities/Typography.css';

const Second_details = () => {
  return (
    <div className="status-container">
      {/* <MainCard title="Status"> */}
      {/* <Box display="flex" justifyContent="center" className="image-container">
       
        <img
          src={image}
          alt="Offline Devices"
          className="status-image"
          style={{ width: '350px', height: '350px' }} // Adjust these values as needed
        />
      </Box> */}

      <Box display="flex" alignItems="center" justifyContent="center" className="status-box">
        <ErrorOutlineIcon className="status-icon" color="error" />
        <Typography sx={{ fontSize: '60px', fontWeight: 'bold' }} color="error" className="status-text">
          Devices are offline
        </Typography>
      </Box>
      {/* </MainCard> */}
    </div>
  );
};

export default Second_details;
