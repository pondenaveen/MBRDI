import React, { useState, useEffect } from 'react';
import { Grid, Typography } from '@mui/material';
import F1_1 from './F1_1';
import F1_2 from './F1_2';
import api from './../../api.js';

const All_IAQ = () => {
    const [timestamp, setTimestamp] = useState(''); 

    useEffect(() => {
        const fetchTimestampStatus = async () => {
            try {
                const response = await api.get('/integration/device/status');
                setTimestamp(response.data.last_updated_time);

            } catch (error) {
                console.error('Error fetching timestamp and status:', error);
            }
        };

        fetchTimestampStatus();
    }, []);

    return (
        <>
            <Typography sx={{ mb: 1, fontSize: '20px', fontWeight: 'bold' }}>
                Individual Sensor Data
            </Typography>
            <Grid container spacing={2}>
                <Grid item xs={12} md={4}>
                    <F1_1 />
                </Grid>
                <Grid item xs={12} md={8}>
                    <F1_2 />
                </Grid>
            </Grid>

            <Grid container spacing={2} sx={{ mt: 1 }}>
                <Grid item xs={12} md={4}>
                    <Typography sx={{ fontWeight: 'bold', color: 'black', fontSize: '18px' }}>
                        Last updated at: {timestamp ? timestamp : 'Loading...'}
                    </Typography> {/* Display timestamp */}
                </Grid>
            </Grid>
        </>
    );
};

export default All_IAQ;
